How to run the Car Driving School management System  Project
1. Download the  zip file
2. Extract the file and copy cdsms folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name cdsmsdb
6. Import cdsmsdbfile(given inside the zip package in sql file folder)
7.Run the script http://localhost/cdsms (frontend)
8. For admin panel http://localhost/cdsms/admin  (admin panel)
Credential for admin panel :
Username: admin
Password: Test@321

